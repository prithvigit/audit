<?php
	/*if(filter_has_var(INPUT_POST, "submit"))
	{
		header("Location: display.php");
	}*/
?>	
<!DOCTYPE html>
<html>
	<head>
		<title>Form Submission</title>
		<link rel="stylesheet" href="https://bootswatch.com/4/lux/bootstrap.min.css">
		<a href="https://www.youtube.com/channel/UC-lHJZR3Gqxm24_Vd_AJ5Yw" target="_blank">
		<img src="collegeplate.jpg" alt="KJSCE" width="100%" height="200" alt="KJSCE"  /></a>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
	</head>
	<body>
		<nav class="navbar navbar-default">
		  <div class="container">
			<div class="navbar-header">    
			  <a class="navbar-brand">Form Submitted</a>
			</div>
		  </div>
		</nav>
		<div class="container">
		<h5><b><i>Your response has been recorded<h5>
		<br><br>
	<!--<form name=myForm method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
		<button type="submit" name="submit" class="btn btn-primary">View Allotment</button>			
        </form>
	-->	
		</div>
	</body>
</html>	